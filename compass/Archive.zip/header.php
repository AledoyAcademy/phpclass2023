<nav class="navbar navbar-expand-lg navbar-light bg-gradient-secondary">
                    <h1>
                        <a class="navbar-brand" href="index.php">
            
							<!-- Attainment     -->
						<img src="images/compass_logo (1).png" alt="" width="300px" >
                        </a>
                    </h1>
                    <button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-lg-auto text-center">
                            <li class="nav-item active  mr-3">
                                <a style="color: black;" class="nav-link" href="index.php">Home
                                    <!-- <span class="sr-only">(current)</span> -->
                                </a>
                            </li>
                            <li class="nav-item  mr-3">
                                <a class="nav-link" href="about.php">about</a>
							</li>
							 <li class="nav-item  mr-3">
                                <a class="nav-link" href="services.php">Services</a>
                            </li>
							<li class="nav-item  mr-3">
                                <a class="nav-link" href="gallery.php">Project</a>
                            </li>
							<li class="nav-item  mr-3">
                                <a class="nav-link" href="Clients.php">Clientele</a>
                            </li>
							<li class="nav-item  mr-3">
                                <a class="nav-link" href="Careers.php">Careers</a>
                            </li>
                            <!-- <li class="nav-item dropdown mr-3">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
                                    aria-expanded="false">
                                    Pages
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="gallery.php">Gallery</a>
									 <a class="dropdown-item" href="typo.php">Typography</a>
                                </div>
                            </li> -->
                            <li class="nav-item mr-3">
                                <a class="nav-link" href="contact.php">contact</a>
                            </li>
                        </ul>
                    </div>
				 </nav>