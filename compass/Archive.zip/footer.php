<div class="container">
			<div class="row">
				
				<div class="col-lg-4 footer-grids">
					<h3>Get in touch</h3>
					<p>Abbey Mortgage Bank Building, Okota, </p>
					<p class="my-2"> Lagos, Nigeria</p>
					<p class="phone">phone: +234 802 36366</p>
					<p class="phone my-2">Fax: +0444 555 6789</p>
					<p class="phone">Mail:
						<a href="mailto:info@compass.com">info@compass.com</a>
					</p>
				</div>
				<div class="col-lg-4 footer-grids">
					<h2>Latest News</h2>
					<div class="d-flex justify-content-around">
						<a href="#" class="col-4">
							<img src="images/g1.jpg" class="img-fluid" alt="Responsive image">
						</a>
						<a href="#" class="col-4">
							<img src="images/g2.jpg" class="img-fluid" alt="Responsive image">
						</a>
						<a href="#" class="col-4">
							<img src="images/g3.jpg" class="img-fluid" alt="Responsive image">
						</a>
					</div>
					<div class="d-flex justify-content-around">
						<a href="#" class="col-4">
							<img src="images/g4.jpg" class="img-fluid" alt="Responsive image">
						</a>
						<a href="#" class="col-4">
							<img src="images/g5.jpg" class="img-fluid" alt="Responsive image">
						</a>
						<a href="#" class="col-4">
							<img src="images/g6.jpg" class="img-fluid" alt="Responsive image">
						</a>
					</div>
				</div>
				<div class="col-lg-4 footer-grids">
					<h3>Twitter feed</h3>
					<ul class="w3agile_footer_grid_list">
						<li>Ut aut reiciendis voluptatibus adipiscing
							<a href="#">example.com</a> alias, ut aut.
							<span>
								<i class="fab fa-twitter"></i> 02 days ago</span>
						</li>
						<li>Itaque earum rerum hic tenetur a sapiente
							<a href="#">example.com</a> ut aut.
							<span>
								<i class="fab fa-twitter"></i> 03 days ago</span>
						</li>
					</ul>
				</div>
			</div>
		</div>